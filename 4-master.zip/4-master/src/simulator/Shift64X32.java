package simulator;

import simulator.network.Link;
import simulator.wrapper.Wrapper;

public class Shift64X32 extends Wrapper {
    public Shift64X32(String label, String stream, Link... links) {
        super(label, stream, links);
    }

    @Override
    public void initialize() {

        
    }
}
