package simulator;

public class PC {
    Register address;
}
